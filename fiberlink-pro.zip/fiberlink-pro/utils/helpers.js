// ── TOAST ──
function toast(msg, type = 'info') {
  const icons = { success: '✓', error: '✕', info: 'ℹ' };
  const colors = { success: '#10b981', error: '#ef4444', info: '#3b82f6' };
  const el = document.createElement('div');
  el.className = `toast toast-${type}`;
  el.innerHTML = `<span style="color:${colors[type]};font-weight:700;font-size:14px">${icons[type]}</span><span>${msg}</span>`;
  document.getElementById('toast-container').appendChild(el);
  setTimeout(() => { el.classList.add('hide'); setTimeout(() => el.remove(), 300); }, 3000);
}

// ── MODAL ──
function openModal(id) {
  const m = document.getElementById(id);
  if (m) { m.classList.add('open'); document.body.style.overflow = 'hidden'; }
}

function closeModal(id) {
  const m = document.getElementById(id);
  if (m) { m.classList.remove('open'); document.body.style.overflow = ''; }
}

document.addEventListener('click', e => {
  if (e.target.classList.contains('modal-overlay')) closeModal(e.target.id);
});

// ── FORMAT ──
function formatCurrency(n) {
  return '$' + Number(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function formatDate(d) {
  if (!d) return '—';
  return new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function statusBadge(s) {
  return `<span class="badge-status status-${s}">${s.charAt(0).toUpperCase()+s.slice(1)}</span>`;
}

function avatarEl(initials, extraClass = '') {
  const colors = ['#2563eb','#8b5cf6','#06b6d4','#10b981','#f59e0b','#ef4444'];
  const idx = (initials.charCodeAt(0) + (initials.charCodeAt(1)||0)) % colors.length;
  return `<div class="avatar ${extraClass}" style="background:linear-gradient(135deg,${colors[idx]},${colors[(idx+2)%colors.length]})">${initials}</div>`;
}

// ── CONFIRM ──
function confirm(msg, cb) {
  if (window.confirm(msg)) cb();
}

// ── STORAGE ──
const Store = {
  get(key) { try { return JSON.parse(localStorage.getItem('flp_'+key)) || null; } catch { return null; } },
  set(key, val) { localStorage.setItem('flp_'+key, JSON.stringify(val)); },
  remove(key) { localStorage.removeItem('flp_'+key); }
};

// ── DEBOUNCE ──
function debounce(fn, ms) {
  let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}
